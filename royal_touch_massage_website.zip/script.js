const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
toggle?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open'); toggle?.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const dateInput = document.querySelector('input[name="date"]');
if (dateInput) {
  const today = new Date();
  const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split('T')[0];
  dateInput.min = localToday;
}
document.querySelectorAll('[data-service]').forEach(link => link.addEventListener('click', () => {
  const select = document.getElementById('serviceSelect');
  if (select) select.value = link.dataset.service;
}));
document.getElementById('bookingForm')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  const message = [
    'ROYAL TOUCH MASSAGE — APPOINTMENT REQUEST',
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Service: ${data.service}`,
    `Session length: ${data.duration}`,
    `Preferred date: ${data.date}`,
    `Preferred time: ${data.time}`,
    `Notes: ${data.notes || 'None'}`,
    '',
    'This is a draft request. Connect a business email/form service before publishing to receive submissions automatically.'
  ].join('\\n');
  const blob = new Blob([message], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'royal-touch-appointment-request.txt';
  a.click();
  URL.revokeObjectURL(url);
  document.getElementById('formMessage').textContent =
    'Your request details were prepared as a text file on this device. This starter version does not send bookings to the business yet. Connect a form service before going live.';
});
